/*
 * hmc5883l.c
 *
 *  Created on: Jul 23, 2025
 *      Author: urvi
 */

#include "hmc5883l.h"
#include <string.h>

static HAL_StatusTypeDef hmc_write_reg(I2C_HandleTypeDef *hi2c, uint8_t reg, uint8_t data) {
    uint8_t buf[2] = {reg, data};
    return HAL_I2C_Master_Transmit(hi2c, HMC5883L_ADDR, buf, 2, HAL_MAX_DELAY);
}

static HAL_StatusTypeDef hmc_read_regs(I2C_HandleTypeDef *hi2c, uint8_t reg, uint8_t *buf, uint8_t len) {
    return HAL_I2C_Mem_Read(hi2c, HMC5883L_ADDR, reg, 1, buf, len, HAL_MAX_DELAY);
}

HAL_StatusTypeDef HMC5883L_Init(I2C_HandleTypeDef *hi2c) {
    // Config Register A: 8-average, 15 Hz, normal measurement
    if (hmc_write_reg(hi2c, HMC5883L_REG_CONFIG_A, 0x70) != HAL_OK) {
        return HAL_ERROR;
    }

    // Config Register B: Gain = 1.3 Ga (default)
    if (hmc_write_reg(hi2c, HMC5883L_REG_CONFIG_B, 0x20) != HAL_OK) {
        return HAL_ERROR;
    }

    // Mode Register: Continuous measurement
    if (hmc_write_reg(hi2c, HMC5883L_REG_MODE, 0x00) != HAL_OK) {
        return HAL_ERROR;
    }

    HAL_Delay(10); // Small delay to settle
    return HAL_OK;
}

HAL_StatusTypeDef HMC5883L_ReadMag(I2C_HandleTypeDef *hi2c, int16_t *mx, int16_t *my, int16_t *mz) {
    uint8_t buf[6];
    if (hmc_read_regs(hi2c, HMC5883L_REG_OUT_X_MSB, buf, 6) != HAL_OK) {
        return HAL_ERROR;
    }

    *mx = (int16_t)((buf[0] << 8) | buf[1]);
    *mz = (int16_t)((buf[2] << 8) | buf[3]);  // note: Z is in middle
    *my = (int16_t)((buf[4] << 8) | buf[5]);

    return HAL_OK;
}

