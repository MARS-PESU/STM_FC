/*
 * qmc5883l.c
 *
 *  Created on: Jul 25, 2025
 *      Author: urvi
 */

#include "qmc5883l.h"
#include <string.h>

HAL_StatusTypeDef QMC5883L_Init(I2C_HandleTypeDef *hi2c)
{
    HAL_StatusTypeDef ret;

    // Soft reset
    uint8_t reset_cmd[2] = {QMC5883L_CONTROL2, 0x80};
    ret = HAL_I2C_Master_Transmit(hi2c, QMC5883L_ADDR, reset_cmd, 2, HAL_MAX_DELAY);
    if (ret != HAL_OK) return ret;
    HAL_Delay(10);

    // Set/Reset period recommended default
    uint8_t sr_cmd[2] = {QMC5883L_SETRESET, 0x01};
    ret = HAL_I2C_Master_Transmit(hi2c, QMC5883L_ADDR, sr_cmd, 2, HAL_MAX_DELAY);
    if (ret != HAL_OK) return ret;

    // Control register 1:
    // OSR=512 (00), RNG=8G (01), ODR=200Hz (11), MODE=Continuous (01)
    // Bits: OSR[7:6], RNG[5:4], ODR[3:2], MODE[1:0]
    uint8_t ctrl1[2] = {QMC5883L_CONTROL1, 0x1D}; // 00011101
    ret = HAL_I2C_Master_Transmit(hi2c, QMC5883L_ADDR, ctrl1, 2, HAL_MAX_DELAY);
    if (ret != HAL_OK) return ret;

    return HAL_OK;
}

HAL_StatusTypeDef QMC5883L_Read(I2C_HandleTypeDef *hi2c, QMC5883L_Data *mag)
{
    uint8_t raw[6];
    HAL_StatusTypeDef ret;

    ret = HAL_I2C_Mem_Read(hi2c, QMC5883L_ADDR, QMC5883L_X_LSB, 1, raw, 6, HAL_MAX_DELAY);
    if (ret != HAL_OK) return ret;

    mag->x = (int16_t)(raw[1] << 8 | raw[0]);
    mag->y = (int16_t)(raw[3] << 8 | raw[2]);
    mag->z = (int16_t)(raw[5] << 8 | raw[4]);

    return HAL_OK;
}

