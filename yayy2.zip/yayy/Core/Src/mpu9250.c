/*
 * mpu9250.c
 *
 *  Created on: Jul 23, 2025
 *      Author: urvi
 */

#include "mpu9250.h"

static HAL_StatusTypeDef mpu9250_write_reg(I2C_HandleTypeDef *hi2c, uint8_t reg, uint8_t data) {
    uint8_t buf[2] = {reg, data};
    return HAL_I2C_Master_Transmit(hi2c, MPU9250_ADDR, buf, 2, HAL_MAX_DELAY);
}

static HAL_StatusTypeDef mpu9250_read_regs(I2C_HandleTypeDef *hi2c, uint8_t reg, uint8_t *buf, uint8_t len) {
    return HAL_I2C_Mem_Read(hi2c, MPU9250_ADDR, reg, 1, buf, len, HAL_MAX_DELAY);
}

HAL_StatusTypeDef MPU9250_Init(I2C_HandleTypeDef *hi2c) {
    uint8_t who_am_i = 0;

    // Check device ID
    if (mpu9250_read_regs(hi2c, MPU9250_WHO_AM_I, &who_am_i, 1) != HAL_OK) {
        return HAL_ERROR;
    }
    if (who_am_i != 0x71 && who_am_i != 0x73 && who_am_i != 0x68) { // MPU9250 or MPU6500 IDs
        return HAL_ERROR;
    }

    // Wake up device
    if (mpu9250_write_reg(hi2c, MPU9250_PWR_MGMT_1, 0x00) != HAL_OK) {
        return HAL_ERROR;
    }
    HAL_Delay(100);

    // Config: DLPF
    if (mpu9250_write_reg(hi2c, MPU9250_CONFIG, 0x03) != HAL_OK) {
        return HAL_ERROR;
    }

    // Gyro full scale ±250 dps
    if (mpu9250_write_reg(hi2c, MPU9250_GYRO_CONFIG, 0x00) != HAL_OK) {
        return HAL_ERROR;
    }

    // Accel full scale ±2g
    if (mpu9250_write_reg(hi2c, MPU9250_ACCEL_CONFIG, 0x00) != HAL_OK) {
        return HAL_ERROR;
    }

    return HAL_OK;
}

HAL_StatusTypeDef MPU9250_ReadAccel(I2C_HandleTypeDef *hi2c, int16_t *ax, int16_t *ay, int16_t *az) {
    uint8_t buf[6];
    if (mpu9250_read_regs(hi2c, MPU9250_ACCEL_XOUT_H, buf, 6) != HAL_OK) {
        return HAL_ERROR;
    }

    *ax = (int16_t)((buf[0] << 8) | buf[1]);
    *ay = (int16_t)((buf[2] << 8) | buf[3]);
    *az = (int16_t)((buf[4] << 8) | buf[5]);

    return HAL_OK;
}

HAL_StatusTypeDef MPU9250_ReadGyro(I2C_HandleTypeDef *hi2c, int16_t *gx, int16_t *gy, int16_t *gz) {
    uint8_t buf[6];
    if (mpu9250_read_regs(hi2c, MPU9250_GYRO_XOUT_H, buf, 6) != HAL_OK) {
        return HAL_ERROR;
    }

    *gx = (int16_t)((buf[0] << 8) | buf[1]);
    *gy = (int16_t)((buf[2] << 8) | buf[3]);
    *gz = (int16_t)((buf[4] << 8) | buf[5]);

    return HAL_OK;
}

