/*
 * ppm.c
 *
 *  Created on: Jul 28, 2025
 *      Author: urvi
 */

#include "ppm.h"

volatile uint16_t ppm_channels[NUM_CHANNELS];
volatile uint8_t channel_index = 0;
volatile uint32_t last_capture = 0;
TIM_HandleTypeDef *ppm_htim;

void PPM_Init(TIM_HandleTypeDef *htim) {
    ppm_htim = htim;
    HAL_TIM_IC_Start_IT(ppm_htim, TIM_CHANNEL_1);
}

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim) {
    if (htim->Instance == ppm_htim->Instance) {
        uint32_t capture = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
        uint32_t diff;

        if (capture >= last_capture)
            diff = capture - last_capture;
        else
            diff = (htim->Init.Period - last_capture) + capture;

        last_capture = capture;

        uint32_t pulse_width_us = (diff * (htim->Init.Prescaler + 1)) / (HAL_RCC_GetPCLK1Freq() / 1000000);

        if (pulse_width_us > SYNC_THRESHOLD) {
            channel_index = 0;
        } else if (channel_index < NUM_CHANNELS) {
            ppm_channels[channel_index++] = pulse_width_us;
        }
    }
}
