/*
 * bmp280.c
 *
 *  Created on: Jul 23, 2025
 *      Author: urvi
 */

#include "bmp280.h"
#include <math.h>

BMP280_CalibData bmp280_calib;

static HAL_StatusTypeDef bmp280_read_calibration(I2C_HandleTypeDef *hi2c) {
    uint8_t calib[24];
    if (HAL_I2C_Mem_Read(hi2c, BMP280_I2C_ADDR, 0x88, 1, calib, 24, HAL_MAX_DELAY) != HAL_OK) {
        return HAL_ERROR;
    }

    bmp280_calib.dig_T1 = (uint16_t)(calib[1] << 8 | calib[0]);
    bmp280_calib.dig_T2 = (int16_t)(calib[3] << 8 | calib[2]);
    bmp280_calib.dig_T3 = (int16_t)(calib[5] << 8 | calib[4]);
    bmp280_calib.dig_P1 = (uint16_t)(calib[7] << 8 | calib[6]);
    bmp280_calib.dig_P2 = (int16_t)(calib[9] << 8 | calib[8]);
    bmp280_calib.dig_P3 = (int16_t)(calib[11] << 8 | calib[10]);
    bmp280_calib.dig_P4 = (int16_t)(calib[13] << 8 | calib[12]);
    bmp280_calib.dig_P5 = (int16_t)(calib[15] << 8 | calib[14]);
    bmp280_calib.dig_P6 = (int16_t)(calib[17] << 8 | calib[16]);
    bmp280_calib.dig_P7 = (int16_t)(calib[19] << 8 | calib[18]);
    bmp280_calib.dig_P8 = (int16_t)(calib[21] << 8 | calib[20]);
    bmp280_calib.dig_P9 = (int16_t)(calib[23] << 8 | calib[22]);

    return HAL_OK;
}

HAL_StatusTypeDef BMP280_Init(I2C_HandleTypeDef *hi2c) {
    uint8_t ctrl_meas[2];

    // Reset
    uint8_t reset[2] = {0xE0, 0xB6};
    HAL_I2C_Master_Transmit(hi2c, BMP280_I2C_ADDR, reset, 2, HAL_MAX_DELAY);
    HAL_Delay(100);

    // Read and store calibration data
    if (bmp280_read_calibration(hi2c) != HAL_OK) {
        return HAL_ERROR;
    }

    // Configure: normal mode, oversampling x1
    ctrl_meas[0] = 0xF4;  // ctrl_meas register
    ctrl_meas[1] = 0x27;  // temp oversample x1, press oversample x1, normal mode
    if (HAL_I2C_Master_Transmit(hi2c, BMP280_I2C_ADDR, ctrl_meas, 2, HAL_MAX_DELAY) != HAL_OK) {
        return HAL_ERROR;
    }

    // Config: standby time and filter
    uint8_t config[2] = {0xF5, 0xA0}; // 1000ms standby, filter off
    if (HAL_I2C_Master_Transmit(hi2c, BMP280_I2C_ADDR, config, 2, HAL_MAX_DELAY) != HAL_OK) {
        return HAL_ERROR;
    }

    return HAL_OK;
}

HAL_StatusTypeDef BMP280_Read(I2C_HandleTypeDef *hi2c, float *temperature, float *pressure, float *altitude) {
    uint8_t data[6];
    if (HAL_I2C_Mem_Read(hi2c, BMP280_I2C_ADDR, 0xF7, 1, data, 6, HAL_MAX_DELAY) != HAL_OK) {
        return HAL_ERROR;
    }

    int32_t adc_P = ((int32_t)data[0] << 12) | ((int32_t)data[1] << 4) | (data[2] >> 4);
    int32_t adc_T = ((int32_t)data[3] << 12) | ((int32_t)data[4] << 4) | (data[5] >> 4);

    // Temperature compensation
    int32_t var1, var2, T;
    var1 = ((((adc_T >> 3) - ((int32_t)bmp280_calib.dig_T1 << 1))) *
            ((int32_t)bmp280_calib.dig_T2)) >> 11;
    var2 = (((((adc_T >> 4) - ((int32_t)bmp280_calib.dig_T1)) *
               ((adc_T >> 4) - ((int32_t)bmp280_calib.dig_T1))) >> 12) *
            ((int32_t)bmp280_calib.dig_T3)) >> 14;
    bmp280_calib.t_fine = var1 + var2;
    T = (bmp280_calib.t_fine * 5 + 128) >> 8;
    *temperature = T / 100.0f;

    // Pressure compensation
    int64_t pvar1, pvar2, p;
    pvar1 = ((int64_t)bmp280_calib.t_fine) - 128000;
    pvar2 = pvar1 * pvar1 * (int64_t)bmp280_calib.dig_P6;
    pvar2 = pvar2 + ((pvar1 * (int64_t)bmp280_calib.dig_P5) << 17);
    pvar2 = pvar2 + (((int64_t)bmp280_calib.dig_P4) << 35);
    pvar1 = ((pvar1 * pvar1 * (int64_t)bmp280_calib.dig_P3) >> 8) +
            ((pvar1 * (int64_t)bmp280_calib.dig_P2) << 12);
    pvar1 = (((((int64_t)1) << 47) + pvar1)) * ((int64_t)bmp280_calib.dig_P1) >> 33;
    if (pvar1 == 0) {
        return HAL_ERROR; // avoid division by zero
    }
    p = 1048576 - adc_P;
    p = (((p << 31) - pvar2) * 3125) / pvar1;
    pvar1 = (((int64_t)bmp280_calib.dig_P9) * (p >> 13) * (p >> 13)) >> 25;
    pvar2 = (((int64_t)bmp280_calib.dig_P8) * p) >> 19;
    p = ((p + pvar1 + pvar2) >> 8) + (((int64_t)bmp280_calib.dig_P7) << 4);
    *pressure = p / 25600.0f; // hPa

    // Altitude estimate (assuming sea level pressure = 1013.25 hPa)
    *altitude = 44330.0f * (1.0f - powf((*pressure) / 1013.25f, 0.1903f));

    return HAL_OK;
}

