/*
 * ppm.h
 *
 *  Created on: Jul 28, 2025
 *      Author: urvi
 */

#ifndef INC_PPM_H_
#define INC_PPM_H_

#include "main.h"

#define NUM_CHANNELS 6
#define SYNC_THRESHOLD 3000  // microseconds

extern volatile uint16_t ppm_channels[NUM_CHANNELS];

void PPM_Init(TIM_HandleTypeDef *htim);


#endif /* INC_PPM_H_ */
