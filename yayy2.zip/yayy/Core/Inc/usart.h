/*
 * usart.h
 *
 *  Created on: Jul 23, 2025
 *      Author: urvi
 */

#ifndef INC_USART_H_
#define INC_USART_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32l4xx_hal.h"

extern UART_HandleTypeDef huart2;

void MX_USART2_UART_Init(void);

#ifdef __cplusplus
}
#endif

#endif /* INC_USART_H_ */
