/*
 * hmc5883l.h
 *
 *  Created on: Jul 23, 2025
 *      Author: urvi
 */

#ifndef INC_HMC5883L_H_
#define INC_HMC5883L_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32l4xx_hal.h"
#include <stdint.h>

#define HMC5883L_ADDR           (0x1E << 1)  // Default 7-bit address shifted for HAL

#define HMC5883L_REG_CONFIG_A   0x00
#define HMC5883L_REG_CONFIG_B   0x01
#define HMC5883L_REG_MODE       0x02
#define HMC5883L_REG_OUT_X_MSB  0x03

HAL_StatusTypeDef HMC5883L_Init(I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef HMC5883L_ReadMag(I2C_HandleTypeDef *hi2c, int16_t *mx, int16_t *my, int16_t *mz);

#ifdef __cplusplus
}
#endif

#endif /* INC_HMC5883L_H_ */
