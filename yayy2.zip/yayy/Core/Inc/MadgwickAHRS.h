/*
 * MadgwickAHRS.h
 *
 *  Created on: Jul 28, 2025
 *      Author: urvi
 */

#ifndef INC_MADGWICKAHRS_H_
#define INC_MADGWICKAHRS_H_

void MadgwickInit(float samplePeriod);
void MadgwickAHRSupdate(float gx, float gy, float gz, float ax, float ay, float az, float mx, float my, float mz);
void getEulerAngles(float *pitch, float *roll, float *yaw);


#endif /* INC_MADGWICKAHRS_H_ */
