/*
 * i2c.h
 *
 *  Created on: Jul 23, 2025
 *      Author: urvi
 */

#ifndef INC_I2C_H_
#define INC_I2C_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32l4xx_hal.h"

/* Global handles */
extern I2C_HandleTypeDef hi2c1;
extern I2C_HandleTypeDef hi2c3;

/* Function prototypes */
void MX_I2C1_Init(void);
void MX_I2C3_Init(void);

#ifdef __cplusplus
}
#endif

#endif /* INC_I2C_H_ */
