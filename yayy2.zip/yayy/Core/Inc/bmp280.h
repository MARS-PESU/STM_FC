/*
 * bmp280.h
 *
 *  Created on: Jul 23, 2025
 *      Author: urvi
 */

#ifndef INC_BMP280_H_
#define INC_BMP280_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32l4xx_hal.h"
#include <stdint.h>

#define BMP280_I2C_ADDR  (0x76 << 1) // GY-91 default address

typedef struct {
    uint16_t dig_T1;
    int16_t dig_T2;
    int16_t dig_T3;
    uint16_t dig_P1;
    int16_t dig_P2;
    int16_t dig_P3;
    int16_t dig_P4;
    int16_t dig_P5;
    int16_t dig_P6;
    int16_t dig_P7;
    int16_t dig_P8;
    int16_t dig_P9;
    int32_t t_fine;
} BMP280_CalibData;

extern BMP280_CalibData bmp280_calib;

HAL_StatusTypeDef BMP280_Init(I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef BMP280_Read(I2C_HandleTypeDef *hi2c, float *temperature, float *pressure, float *altitude);

#ifdef __cplusplus
}
#endif

#endif /* INC_BMP280_H_ */
