/*
 * qmc5883l.h
 *
 *  Created on: Jul 25, 2025
 *      Author: urvi
 */

#ifndef INC_QMC5883L_H_
#define INC_QMC5883L_H_

#include "stm32l4xx_hal.h"

#define QMC5883L_ADDR         (0x0D << 1) // default I2C address
#define QMC5883L_X_LSB        0x00
#define QMC5883L_CONTROL1     0x09
#define QMC5883L_CONTROL2     0x0A
#define QMC5883L_SETRESET     0x0B

typedef struct {
    int16_t x;
    int16_t y;
    int16_t z;
} QMC5883L_Data;

HAL_StatusTypeDef QMC5883L_Init(I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef QMC5883L_Read(I2C_HandleTypeDef *hi2c, QMC5883L_Data *mag);


#endif /* INC_QMC5883L_H_ */
