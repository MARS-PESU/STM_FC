/*
 * gpio.h
 *
 *  Created on: Jul 24, 2025
 *      Author: urvi
 */

#ifndef INC_GPIO_H_
#define INC_GPIO_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32l4xx_hal.h"

// 👉 If you have a user LED or other GPIO pins, define them here
// Example: On NUCLEO-L432KC, LD3 is on PB3 (check your board schematic)
#define LD3_Pin        GPIO_PIN_3
#define LD3_GPIO_Port  GPIOB

void MX_GPIO_Init(void);

#ifdef __cplusplus
}
#endif

#endif /* INC_GPIO_H_ */
